CREATE DATABASE comercio_sa;
SELECT * FROM cadastro.cliente;

CREATE TABLE clientes (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nome VARCHAR(255) NOT NULL,
  cpf VARCHAR(14) NOT NULL UNIQUE,
  data_nascimento DATE NOT NULL,
  endereco VARCHAR(255) NOT NULL,
  data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE contatos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  id_cliente INT NOT NULL,
  tipo_contato ENUM('Telefone', 'E-mail') NOT NULL,
  valor_contato VARCHAR(255) NOT NULL,
  observacao VARCHAR(255),
  FOREIGN KEY (id_cliente) REFERENCES clientes (id) ON DELETE CASCADE
);

CREATE INDEX idx_cpf ON clientes (cpf);
CREATE INDEX idx_id_cliente ON contatos (id_cliente);

UPDATE clientes
SET nome = 'novo_nome',
    cpf = 'novo_cpf',
    data_nascimento = 'nona_data_nascimento',
    endereco = 'novo_endereco'
    
WHERE id = 'id_do_cliente';

DELETE FROM clientes
WHERE id = 'id_do_cliente';

SELECT * FROM clientes




  
