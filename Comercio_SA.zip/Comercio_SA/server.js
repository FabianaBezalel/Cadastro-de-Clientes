const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

// Configurar middleware
app.use(cors());
app.use(bodyParser.json());

// Configurar conexão com o banco de dados
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'sua_senha',
    database: 'comercio_sa'
});

// Conectar ao banco de dados
db.connect(err => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err);
        return;
    }
    console.log('Conectado ao banco de dados MySQL');
});

// Rota para cadastrar cliente
app.post('/clientes', (req, res) => {
    const { nome, cpf, data_nascimento, endereco } = req.body;

    if (!nome || !cpf || !data_nascimento || !endereco) {
        return res.status(400).send({ message: 'Todos os campos são obrigatórios.' });
    }

    const sql = 'INSERT INTO clientes (nome, cpf, data_nascimento, endereco) VALUES (?, ?, ?, ?)';
    db.query(sql, [nome, cpf, data_nascimento, endereco], (err, result) => {
        if (err) {
            console.error('Erro ao cadastrar cliente:', err);
            return res.status(500).send({ message: 'Erro ao cadastrar cliente.', error: err });
        }

        res.send({ id: result.insertId, nome, cpf, data_nascimento, endereco });
    });
});

// Rota para listar clientes
app.get('/clientes', (req, res) => {
    const sql = 'SELECT * FROM clientes';
    db.query(sql, (err, results) => {
        if (err) {
            console.error('Erro ao listar clientes:', err);
            return res.status(500).send({ message: 'Erro ao listar clientes.', error: err });
        }
        res.send(results);
    });
});

// Rota para editar cliente
app.put('/clientes/:id', (req, res) => {
    const { id } = req.params;
    const { nome, cpf, data_nascimento, endereco } = req.body;

    const sql = 'UPDATE clientes SET nome = ?, cpf = ?, data_nascimento = ?, endereco = ? WHERE id = ?';
    db.query(sql, [nome, cpf, data_nascimento, endereco, id], (err, result) => {
        if (err) {
            console.error('Erro ao editar cliente:', err);
            return res.status(500).send({ message: 'Erro ao editar cliente.', error: err });
        }

        res.send({ message: 'Cliente atualizado com sucesso!' });
    });
});

// Rota para excluir cliente
app.delete('/clientes/:id', (req, res) => {
    const { id } = req.params;
    const sql = 'DELETE FROM clientes WHERE id = ?';

    db.query(sql, [id], (err, result) => {
        if (err) {
            console.error('Erro ao excluir cliente:', err);
            return res.status(500).send({ message: 'Erro ao excluir cliente.', error: err });
        }

        res.send({ message: 'Cliente excluído com sucesso!' });
    });
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});